import { GetStaticProps, GetStaticPaths } from 'next';
import Link from 'next/link';
import Head from 'next/head';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import Layout from '../../../../../components/Layout';

import { ICourse, getAllCourses, getCourseByTeacherAndName } from '../../../../../lib/dataUtils';
import { trackCourseView } from '../../../../../lib/gtag';
import { generateOptimizedCourseStructuredData } from '../../../../../lib/structuredData';

const VideoPlayer = dynamic(() => import('../../../../../components/VideoPlayer'), {
  loading: () => (
    <div className="flex h-64 items-center justify-center rounded-lg bg-muted">
      <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
    </div>
  ),
});

interface TeacherCoursePlayPageProps {
  course: ICourse | null;
  categoryName: string;
  courseName: string;
  teacherSlug: string;
}

export default function TeacherCoursePlayPage({
  course,
  categoryName,
  courseName,
  teacherSlug,
}: TeacherCoursePlayPageProps) {
  const router = useRouter();

  const encodedTeacherSlug = encodeURIComponent(teacherSlug);
  const encodedCourseName = encodeURIComponent(courseName);

  useEffect(() => {
    if (!course) return;
    if (course.videoType === 'redirect' && course.redirecturl) {
      window.location.href = course.redirecturl;
    }
  }, [course]);

  useEffect(() => {
    if (course && course.courseName) {
      trackCourseView(course.courseName, categoryName);
    }
  }, [course, categoryName]);

  if (!course) {
    return (
      <>
        <Head>
          <title>Course Not Found | Unlocked Coding</title>
          <meta name="robots" content="noindex, follow" />
        </Head>
        <Layout>
          <div className="container mx-auto px-4 py-8">
            <div className="text-center">
              <h1 className="mb-4 text-4xl font-bold text-foreground">Course Not Found</h1>
              <p className="mb-8 text-muted-foreground">
                The course you're looking for doesn't exist.
              </p>
              <Link
                href={`/teacher/${encodedTeacherSlug}`}
                className="rounded-lg bg-primary px-6 py-3 text-primary-foreground transition-opacity hover:opacity-90"
              >
                Back to Teacher
              </Link>
            </div>
          </div>
        </Layout>
      </>
    );
  }

  if (course.videoType === 'redirect' && course.redirecturl) {
    return (
      <>
        <Head>
          <title>{course.courseName} | Unlocked Coding</title>
          <meta name="description" content={course.des} />
          <link
            rel="canonical"
            href={`https://unlockedcoding.com/teacher/${encodedTeacherSlug}/${encodedCourseName}/play`}
          />
          <meta name="robots" content="noindex, follow" />
        </Head>
        <Layout>
          <div className="container mx-auto px-4 py-8">
            <div className="text-center">
              <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-primary"></div>
              <h1 className="mb-4 text-2xl font-bold text-foreground">Redirecting...</h1>
              <p className="mb-8 text-muted-foreground">
                You are being redirected to the external course.
              </p>
              <p className="text-sm text-muted-foreground">
                If you are not redirected automatically,
                <a
                  href={course.redirecturl}
                  className="ml-1 text-primary hover:underline"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  click here
                </a>
              </p>
            </div>
          </div>
        </Layout>
      </>
    );
  }

  const structuredData = generateOptimizedCourseStructuredData(course, categoryName, courseName, {
    teacherSlug: course?.instructorSlug || teacherSlug,
  });
  const instructorDisplayName =
    course.instructorDisplayName || course.instructorSlug || course.teacherId || course.instructorname || 'Instructor';




  return (
    <>
      <Head>
        <title>{`${course.courseName} - ${instructorDisplayName || 'Free Course'} | Unlocked Coding`}</title>
        <meta name="description" content={course.des} />
        <link
          rel="canonical"
          href={`https://unlockedcoding.com/teacher/${encodedTeacherSlug}/${encodedCourseName}/play`}
        />

        <meta property="og:title" content={course.courseName} />
        <meta property="og:description" content={course.des} />
        <meta property="og:image" content={course.imageofcourse} />
        <meta
          property="og:url"
          content={`https://unlockedcoding.com/teacher/${encodedTeacherSlug}/${encodedCourseName}/play`}
        />
        <meta property="og:type" content="video.course" />
        <meta property="og:site_name" content="Unlocked Coding" />

        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={course.courseName} />
        <meta name="twitter:description" content={course.des} />
        <meta name="twitter:image" content={course.imageofcourse} />

        <meta property="video:duration" content="3600" />
        <meta property="video:release_date" content={new Date().toISOString()} />
        <meta property="video:tag" content={course.coursecategory} />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
        />
      </Head>
      <Layout>
        <div className="container mx-auto px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
          <div className="mb-4 sm:mb-6">
            <Link
              href={`/teacher/${encodedTeacherSlug}/${encodedCourseName}`}
              className="mb-3 inline-block text-sm text-primary transition-opacity hover:opacity-80 sm:text-base"
            >
              ← Back to Course Info
            </Link>
          </div>

          <VideoPlayer course={course} />
        </div>
      </Layout>
    </>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  try {
    const courses = getAllCourses();

    const paths = courses.map((course) => ({
      params: {
        instructorname: course.instructorSlug || course.teacherId || course.instructorname,
        course: course.courseName,
      },
    }));

    return {
      paths,
      fallback: false,
    };
  } catch (error) {
    console.error('Error generating static paths for teacher course play pages:', error);
    return {
      paths: [],
      fallback: false,
    };
  }
};

export const getStaticProps: GetStaticProps = async ({ params }) => {
  try {
    const teacherSlug = params?.instructorname as string;
    const courseName = params?.course as string;

    const course = getCourseByTeacherAndName(teacherSlug, courseName);

    if (!course) {
      return {
        notFound: true,
      };
    }

    return {
      props: {
        course,
        categoryName: course.coursecategory,
        courseName,
        teacherSlug: course.instructorSlug || teacherSlug,
      },
    };
  } catch (error) {
    console.error('Error fetching teacher course play page:', error);
    return {
      props: {
        course: null,
        categoryName: '',
        courseName: params?.course as string,
        teacherSlug: params?.instructorname as string,
      },
    };
  }
};

